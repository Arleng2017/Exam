import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { CallApiProvider } from '../../providers/call-api/call-api';

/**
 * Generated class for the TaxPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-tax',
  templateUrl: 'tax.html',
})
export class TaxPage {
  moneyInput: number;
  money: number
  tax: number;
  year: Number;
  balance = [];
  balancePerYear = [];
  taxPerYear = [];
  taxTotol: number = 0;
  data: any;
  constructor(public navCtrl: NavController, public navParams: NavParams, public callApi: CallApiProvider) {
    this.get();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad TaxPage');
  }


  taxSum() {
    this.money = this.moneyInput;
    this.balancePerYear = [];

    for (let index = 0; index < this.year; index++) {

      this.taxTotol = (Number(this.money) / 100 * Number(this.tax)) + Number(this.money);
      this.balancePerYear.push(this.taxTotol.toFixed(2));
      this.taxPerYear.push((Number(this.money) / 100 * Number(this.tax)));
      this.balance.push(this.money);
      this.money = this.taxTotol;

    }
    //this.get();


  }

  get() {
    this.callApi.GetAllTax().subscribe(data => {
     this.data = data;
      console.log(this.data);
    });
  }

}
