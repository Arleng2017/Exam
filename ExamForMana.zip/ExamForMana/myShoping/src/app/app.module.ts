import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule, TapClick } from 'ionic-angular';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
// import { ListPage } from '../pages/list/list';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { CallApiProvider } from '../providers/call-api/call-api';
// import { MenPage } from '../pages/men/men';
// import { WomenPage } from '../pages/women/women';
// import { SkirtPage } from '../pages/skirt/skirt';
// import { PantPage } from '../pages/pant/pant';
// import { LoginPage } from '../pages/login/login';
import { FileEncryption } from '@ionic-native/file-encryption';
import { TaxPage } from '../pages/tax/tax';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    MyApp,
    HomePage,
    // ListPage,
    // MenPage,
    // WomenPage,
    // SkirtPage,
    // PantPage,
    // LoginPage,
    TaxPage
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    // ListPage,
    // MenPage,
    // WomenPage,
    // SkirtPage,
    // PantPage,
    // LoginPage,
    TaxPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    CallApiProvider,
    FileEncryption,
    CallApiProvider 
  ]
})
export class AppModule {}
