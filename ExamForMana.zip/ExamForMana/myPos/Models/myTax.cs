namespace myPos.Models
{
    public class myTax

    {
        public double Tax { get; set; }
        // public string Name { get; set; }
        // public string  Status{ get; set; }
        //  public int Que{ get; set; }
        //   public string Time { get; set; }
        
        
       
    }
}