﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using myPos.Models;

namespace myPos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TaxController : ControllerBase
    {
        public static List<myTax> myTax = new List<myTax>
        {
             new myTax{
                Tax=0.00
          

            },
            new myTax{
                Tax=3.00
          

            },
             new myTax{
                Tax=7.00
          

            },
             new myTax{
                Tax=10.00
          

            },
             new myTax{
                Tax=12.00
                

            }

        };
    
        [HttpGet]
        public List<myTax> GetAllTax()
        {
            return myTax;

        }

        // // [HttpGet("{id}")]
        // // public myPatient GetProduct(String id){
        // //     return  myProduct.Find(it =>it.Id==id);
        // // }
        // [HttpPost]
        // public void CreateProduct([FromBody]myPatient newPatient)
        // {
        //     newPatient.Id = Guid.NewGuid().ToString();
        //     myPatient.Add(newPatient);
        // }


        // [HttpGet("{name}")]
        // public myPatient GetPatient(String name)
        // {
        //     return myPatient.Find(it => it.Name == name);
        // }

        // [HttpPut]
        // public void UpdatePatient([FromBody]myPatient newPatient)
        // {
        //     var oldPatient = myPatient.Find(it => it.Id == newPatient.Id);
        //     myPatient.Remove(oldPatient);
        //     myPatient.Add(newPatient);
        // }
        //  [HttpGet("{que}")]
        // public myPatient GetPatientByQue(int que){
        //     return  myPatient.Find(it =>it.Que==que);
        // }



    }
}
